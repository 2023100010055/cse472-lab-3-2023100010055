// CSE472 Lab 04: Forms, Validation, JSON and Local Storage
// SEU Innovation Summit - Information and Registration Page

// ---------- Features carried forward from the previous lab ----------

// Number of seats still available for the Summit
let availableSeats = 12;

// Show the current registration status
function checkRegistration() {
    let message = document.getElementById("registrationStatus");
    message.textContent = "Registration is currently open.";
}

// Check whether seats are available and show the result
function checkSeats() {
    let message = document.getElementById("seatMessage");

    if (availableSeats > 0) {
        message.textContent = "Seats are available. Remaining seats: " + availableSeats;
    } else {
        message.textContent = "Sorry, no seats are available.";
    }
}

// Read the typed name and show a personal greeting
function showGreeting() {
    let name = document.getElementById("studentName").value;
    let output = document.getElementById("greetingMessage");
    output.textContent = "Welcome, " + name + "!";
}

// Show a check-in reminder for participants
function showReminder() {
    let reminder = document.getElementById("reminderMessage");
    reminder.textContent = "Reminder: Bring your SEU student ID card and arrive by 09:30 for check-in at the Convocation Lobby.";
}

// ---------- Lab 04: read, validate, group, convert, save ----------

function submitRegistration() {
    // 1. Read the four form values
    let studentId = document.getElementById("studentId").value;
    let name = document.getElementById("studentName").value;
    let email = document.getElementById("studentEmail").value;
    let workshop = document.getElementById("workshop").value;
    let message = document.getElementById("formMessage");

    // 2. Check that nothing important is missing
    if (studentId === "") {
        message.textContent = "Please enter your student ID.";
        return;
    }

    if (name === "") {
        message.textContent = "Please enter your full name.";
        return;
    }

    if (email === "") {
        message.textContent = "Please enter your email address.";
        return;
    }

    if (workshop === "") {
        message.textContent = "Please select a track.";
        return;
    }

    // 3. Group the four values in one object
    let registration = {
        studentId: studentId,
        name: name,
        email: email,
        workshop: workshop
    };

    // 4. Convert the object to JSON text
    let jsonData = JSON.stringify(registration);

    // 5. Save the JSON text in the browser
    localStorage.setItem("registration", jsonData);

    // 6. Show the JSON and a confirmation message
    document.getElementById("jsonOutput").textContent = jsonData;
    message.textContent = "Registration saved successfully.";
}

// Load the saved registration and show it as a readable sentence
function showSavedRegistration() {
    let savedData = localStorage.getItem("registration");
    let output = document.getElementById("savedMessage");

    if (savedData === null) {
        output.textContent = "No saved registration was found.";
        return;
    }

    let registration = JSON.parse(savedData);

    output.textContent = registration.name + " (" + registration.studentId +
        ") registered for " + registration.workshop + ".";
}

// Remove the saved practice data so testing can start again
function clearRegistration() {
    localStorage.removeItem("registration");
    document.getElementById("jsonOutput").textContent = "No registration saved yet.";
    document.getElementById("savedMessage").textContent = "Saved registration cleared.";
}
